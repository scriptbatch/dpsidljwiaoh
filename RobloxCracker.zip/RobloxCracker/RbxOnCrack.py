import time
import random
import hashlib
import base64
import sys

def encrypt_fake_data(data):
    """Fake encryption function to make the script look legit."""
    return base64.b64encode(hashlib.sha256(data.encode()).digest()).hex()

def fake_progress_bar():
    """A fake progress bar for 'hacking' effect."""
    for _ in range(30):
        sys.stdout.write(random.choice(["|", "/", "-", "\\"]) + "\r")
        sys.stdout.flush()
        time.sleep(0.1)

def generate_fake_hex_dump():
    """Generates a fake hex dump to look advanced."""
    print("\nExtracting raw user credentials:\n")
    for _ in range(5):
        fake_hex = " ".join(f"{random.randint(0,255):02x}" for _ in range(16))
        print(f"0x{random.randint(1000,9999):04x}  {fake_hex}  |{random.choice('abcdef0123456789')*16}|")
        time.sleep(0.3)

def fake_hack():

    print(r"""
  ____       _     _            ____                _             
 |  _ \ ___ | |__ | | _____  __/ ___|_ __ __ _  ___| | _____ _ __ 
 | |_) / _ \| '_ \| |/ _ \ \/ / |   | '__/ _` |/ __| |/ / _ \ '__|
 |  _ < (_) | |_) | | (_) >  <| |___| | | (_| | (__|   <  __/ |   
 |_| \_\___/|_.__/|_|\___/_/\_\\____|_|  \__,_|\___|_|\_\___|_|   
                                                                
""")
    print("Connecting to Roblox authentication servers...")
    fake_progress_bar()

    print("Bypassing multi-layered security protocols...")
    time.sleep(2)

    print("Injecting brute-force decryption algorithms...")
    fake_progress_bar()

    generate_fake_hex_dump()

    print("\nDecrypting user credentials...")
    fake_progress_bar()

    passwords = ["o3G2n@kLm!", "Px42!bT9m", "Zk3#rL7qW", "Hf9$8xM2p", "Tr1!5Kd7"]
    fake_password = random.choice(passwords)

    encrypted_pass = encrypt_fake_data(fake_password)

    print("\n[INFO] Encrypted Hash: ", encrypted_pass[:16] + "..." + encrypted_pass[-8:])
    time.sleep(2)

    print(f"\nSUCCESS! Password found: {fake_password}")
    print("\nAccount hacked, user info will be sent to you soon")

fake_hack()
